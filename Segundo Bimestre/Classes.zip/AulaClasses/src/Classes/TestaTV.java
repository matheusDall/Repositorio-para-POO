package Classes;

public class TestaTV {

	public static void main(String[] args) {
		Tv tv1;
		tv1 = new Tv();
		
		tv1.canal = 150;
		tv1.volume = 3;
		
		tv1.aumentarVolume();
		tv1.aumentarVolume();
		tv1.diminuirVolume();
		
		tv1.trocarCanal(50);
		
		System.out.println(tv1.mostrar());
		
		Tv tv2;
		tv2 = new Tv();
		
		tv2.canal = 150;
		tv2.volume = 3;
		
		tv2.aumentarVolume();
		tv2.aumentarVolume();
		tv2.diminuirVolume();
		
		tv2.trocarCanal(50);
		
		System.out.println("Dados da Tv2:\n" + tv2.mostrar());
		
	}
}