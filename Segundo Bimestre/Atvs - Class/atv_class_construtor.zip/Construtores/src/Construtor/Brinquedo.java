package Construtor;
public class Brinquedo {
	
	private String nome; 
	private String faixaEtaria;
	private float preco; 
	
	
	public Brinquedo(){
		
	}
	public Brinquedo(String nome){
		
		this.nome = nome;
	}
	public Brinquedo(String nome, float preco){
		
		this.preco = preco;
		this.nome = nome;
	}
	
	public String getFaixaEtaria(){
		return faixaEtaria;
		
	}
	
	public void setFaixaEtaria(String faixaEtaria){
		if(faixaEtaria == "0 a 2" || faixaEtaria == "3 a 5" || faixaEtaria == "6 a 10" || faixaEtaria == "acima de 10") {
			this.faixaEtaria = faixaEtaria;
		}
		else{
			
			this.faixaEtaria = "Faixa etaria invalida";
		}
		
	}
	public void mostrar() {
		System.out.println("Nome do brinquedo: " + nome + "\nFaixa etaria: " + faixaEtaria + "\nPreço: " + preco + '\n');
	}
}