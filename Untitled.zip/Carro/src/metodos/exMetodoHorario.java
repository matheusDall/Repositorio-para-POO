package metodos;

public class exMetodoHorario {
	public int hor, min, seg;
	
	public void setHorario(int h, int m, int s) {
		hor = h;
		min = m;
		seg = s;
	}
	public String mostrarString() {
		String mostrar = hor + ":" + min + ":" + seg;
		return mostrar;
	}

}

meu aniversario;