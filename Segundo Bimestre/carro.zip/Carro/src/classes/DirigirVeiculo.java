package classes;

public class DirigirVeiculo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Veiculo monza;
		monza = new Veiculo();
		
		monza.ligar();
		
		monza.acelerar();
		monza.acelerar();
		monza.acelerar();
		monza.acelerar();
		monza.acelerar();
			
		System.out.println(monza.mostrarStatus());
		
		monza.desligar();
		
		System.out.println(monza.mostrarStatus());
	
	}
}