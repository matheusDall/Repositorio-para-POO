package metodos;

public class TestarHorario {
	
	public static void main(String[] args) {
		exMetodoHorario h1 = new exMetodoHorario();
		h1.setHorario(10, 50, 0);
		
		exMetodoHorario h2 = new exMetodoHorario();
		h2.setHorario(99, 59, 59);
		
		System.out.println(h1.mostrarString());
		System.out.println(h2.mostrarString());
	}

}
