package atvClass;

public class Tempo {
	
	public long Quantidade(){
		return 0;
	}
	
	public String toString(){
		return "";
	}
}