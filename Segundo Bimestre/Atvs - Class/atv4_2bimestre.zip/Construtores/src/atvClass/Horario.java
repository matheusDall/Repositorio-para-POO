package atvClass;

public class Horario extends Tempo {
	
	private Integer hora;
	private Integer minuto;
	private Integer segundo;
	
	public Horario(){
	}
	
	public Horario(Integer hora, Integer minuto, Integer segundo){
		setHora(hora);
		setMinuto(minuto);
		setSegundo(segundo);
	}
	
	public Integer getHora(){
		return hora;
	}
	
	public void setHora(Integer hora){
		this.hora = hora;
	}
	
	public Integer getMinuto(){
		return minuto;
	}
	
	public void setMinuto(Integer minuto){
		this.minuto = minuto;
	}
	
	public Integer getSegundo(){
		return segundo;
	}
	
	public void setSegundo(Integer segundo){
		this.segundo = segundo;
	}
	
	public Long quantidade(){
		long qtd = hora * 3600 + minuto * 60 + segundo;
		return qtd;
		
	}
	
	public String toString(){
		return hora + ":" + minuto + ":" + segundo;
	}
}