package Construtor;

public class TestarTelevisor {

	public static void main(String[] args) {
		Televisor tv1 = new Televisor(); // chama o construtor que nao requisita valores
		Televisor tv2 = new Televisor(2); // chama o construtor que requisita 1 valor
		Televisor tv3 = new Televisor(20, 30); // chama o construtor q requyisita dois valores
		
		tv1.mostrar();
		tv2.mostrar();
		tv3.mostrar();	
	}
}