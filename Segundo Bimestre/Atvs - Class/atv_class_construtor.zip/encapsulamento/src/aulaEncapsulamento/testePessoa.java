package aulaEncapsulamento;

public class testePessoa {

	public static void main(String[] args) 
	{
		Pessoa Pess1;
		Pess1 = new Pessoa();			
		Pess1.setNome("Dani");
		Pess1.setEndereco("Clarito");
		System.out.print("Nome: " + Pess1.getNome() + "Endereço: " + Pess1.getEndereco());
	}
}