package aulaEncapsulamento;

public class Pessoa{
	
	private String nome;
	private String endereco;
	public void setNome(String nome)
	{
		this.nome = nome;
	}
	public String getNome()
	{
		return nome;
	}
	public void setEndereco(String endereco)
	{
		this.endereco = endereco;
	}
	public String getEndereco()
	{
		return endereco;
	}
}