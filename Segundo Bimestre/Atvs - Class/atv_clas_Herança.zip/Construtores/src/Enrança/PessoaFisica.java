package Enrança;

public class PessoaFisica extends Pessoa {
	private String rg;
	
	public void setRg(String rg){
		this.rg = rg;
	}
	public String getrg(){
		return rg;
	}

}
