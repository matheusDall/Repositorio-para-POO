package Enrança;

public class TestaPessoa {

	public static void main(String[] args) {
		Funcionario funcionario1 = new Funcionario();
		PessoaJuridica empresa = new PessoaJuridica();
		
		funcionario1.setNome("Carlitos Guanabara");
		funcionario1.setRg("882.2464.693");
		funcionario1.setCartao("4984099900247491");
		
		empresa.setNome("Carvalho Escuro LTDA");
		empresa.setCnpj("3725988210001");
		
		System.out.println("Mone: " + funcionario1.getNome() + "\nRG: " + funcionario1.getrg() + "\nCartao: " + funcionario1.getCartao() + "\n");
		
		System.out.println("Empresa: " + empresa.getNome() + "\nCNPJ: " + empresa.getCnpj());
	

	}

}