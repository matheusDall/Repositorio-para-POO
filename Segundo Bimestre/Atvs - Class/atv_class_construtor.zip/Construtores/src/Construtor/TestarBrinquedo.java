package Construtor;

public class TestarBrinquedo {

	public static void main(String[] args) {
		Brinquedo b1 = new Brinquedo();
		Brinquedo b2 = new Brinquedo("uranionauta");
		Brinquedo b3 = new Brinquedo("aviaozinho", 45);
		
		b1.setFaixaEtaria("nada aqui");
		b2.setFaixaEtaria("3 a 5");
		b3.setFaixaEtaria("6 a 10");
		
		b1.mostrar();
		b2.mostrar();
		b3.mostrar();
	}
}