package atvClass;
import java.util.Scanner;

public class testarTempo {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Informe os valores de entrada para formato,valor1,valor2,valor3:");
		String ent = input.next();
		
		String[] entra = ent.split(","); //transforma o input anterior em uma arraylist(lista de valores)
	
		String tipo = entra[0]; //acessa o valor na posiçao 0
		
		Integer n1 = Integer.parseInt(entra[1]); //acessa um valor na posiçao 1 e se ele for um numero, o converte para integer
		
		Integer n2 = Integer.parseInt(entra[2]);
		
		Integer n3 = Integer.parseInt(entra[3]);
		
		if(tipo.equalsIgnoreCase("tempo")){ //iguinorando se as letras sao ou nao maiusculas, verifica se "tipo" é igual a palavra"tempo"
			
			Tempo temp = new Tempo();
			System.out.println("Exibindo Tempo");
			
			System.out.println(temp.toString());
			System.out.println(temp.Quantidade());
			
			input.close();
			
			return;
			
		}
		if(tipo.equalsIgnoreCase("horario")){
			Horario Hora = new Horario(n1, n2, n3);
			System.out.println("Exibindo Horario");
			
			Hora.setHora(n1);
			Hora.setMinuto(n2);
			Hora.setSegundo(n3);
			
			System.out.println(Hora.toString());
			System.out.println(Hora.quantidade());
			
			input.close();
			
			return;
				
		}
		if(tipo.equalsIgnoreCase("data")){	
			Data dat = new Data(n1, n2, n3);
			System.out.println("Exibindo Data");
			
			dat.setDia(n1);
			dat.setMes(n2);
			dat.setAno(n3);
			
			System.out.println(dat.toString());
			System.out.println(dat.Quantidade());
			
			input.close();
			
			return;
			
		}
		else{
			System.out.println("Esse tipo de formaçao não esta cadastrado \nInfore os dados semelhante ao modelo 'formato,valor1,valor2,valor3' \nOpçoes para formato: \n'data' \n'horario' \n'tempo'");
			
			input.close();
			
			return;
		}
	}
}